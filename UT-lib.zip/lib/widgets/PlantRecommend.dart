import 'package:athang_v01/widgets/PlantCart.dart';
import 'package:flutter/material.dart';

class PlantRecommend extends StatelessWidget{
  const PlantRecommend({super.key});

  @override
  Widget build(BuildContext context){
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 15),
      child: Column(
        children: [
          // ignore: avoid_unnecessary_containers
          Container(
            child: const Row(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text('Recommended',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),

                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text('Indoor',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                  ),

                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text('Outdoor',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                  ),

                ),
              ],
            ),
          ),
          // ignore: avoid_unnecessary_containers
          Container(
            padding: EdgeInsets.only(left: 10),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  PlantCart(),
                   PlantCart(),
                    PlantCart()
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}