import 'package:athang_v01/widgets/PlantSmallCart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class PlantReviewed extends StatelessWidget{
  const PlantReviewed({super.key});

  @override
  Widget build(BuildContext context){
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(5),
      child: Column(
         crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Recently reviewed', style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),),
          Container(
            margin: const EdgeInsets.only(top: 20),
            child: const SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  PlantSmallCart(),
                  PlantSmallCart(),
                  PlantSmallCart(),
                  PlantSmallCart(),
                ],
              ),
            ),
          )
        ],
        
      )
      
     
    );
  }
}