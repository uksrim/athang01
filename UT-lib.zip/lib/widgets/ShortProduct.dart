import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class ShortProduct extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        //styles here
          color:Colors.black,
          width: 156,
          height: 160,
      ),
    );
  }
}