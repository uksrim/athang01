import 'package:flutter/cupertino.dart';

class PlantLatestDtl extends StatelessWidget{
  const PlantLatestDtl({super.key});

  @override
  Widget build(BuildContext context){
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10),
      margin: EdgeInsets.only(top:15),
      child: Row(
        children: [
          Container(
            clipBehavior: Clip.hardEdge,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(16)),
            child: Image.network('https://cdn.pixabay.com/photo/2018/09/06/23/37/hydrangea-3659614_1280.jpg',
          fit: BoxFit.cover,
          width: 100,
          height: 100,
          ),          
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Name of Plant'),
                  Text('Description'),
                ],
              ),
            ),
          )
        ],
      )
    );
  }
}