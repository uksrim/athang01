import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class PlantSmallCart extends StatelessWidget{
  const PlantSmallCart({super.key});

  @override
  Widget build(BuildContext context){
    return Container(
      child: Row(
        children: [
          Container(
            clipBehavior: Clip.hardEdge,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),),
            
            child: Image.network('https://cdn.pixabay.com/photo/2024/01/19/18/00/hydrangeas-8519528_960_720.jpg',
            fit: BoxFit.cover,
            width: 100,
            height: 100,
             
            )
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child:const Column(            
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [                
                 Text('Plant Name', style: TextStyle(fontSize: 15),),
                  Text('Description', style: TextStyle(fontSize: 12),)
              ],
            )
          )
        ],
      ),
    );
  }
}