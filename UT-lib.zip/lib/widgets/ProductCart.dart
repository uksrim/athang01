import 'package:flutter/material.dart';

class ProductCard extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            height: 900,
            child: Image.network(
              "https://cdn.pixabay.com/photo/2024/05/05/05/55/goose-8740266_1280.jpg",
              fit: BoxFit.cover,
              width: double.infinity,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 66),
            alignment: Alignment.center,
            child: Text(
              'Welcome to the',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            
            ),
          ),
           Container(
            margin: EdgeInsets.only(top: 0),
            alignment: Alignment.center,
            child: Text(
              'World of Insects',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
          ),
          
          Container(
            margin: EdgeInsets.only(top: 15),
            alignment: Alignment.center,
            child: Text(
              'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.',
              style: TextStyle(fontSize: 14),
            ),
          )
        ],
      ),
    );
  }
}