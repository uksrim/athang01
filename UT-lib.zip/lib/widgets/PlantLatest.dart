import 'package:athang_v01/widgets/PlantLatestDtl.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class PlantLatest extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 20,horizontal: 20),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Latest Plants on Shelf', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
          PlantLatestDtl(),PlantLatestDtl(),PlantLatestDtl()
        ],
      ),
    );
  }
}