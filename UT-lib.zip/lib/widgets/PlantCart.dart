import 'package:flutter/material.dart';

class PlantCart extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Container(
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.only(right: 10),
     // color: Colors.blueGrey,
       decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12), color: Colors.blue),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children:[
          Container(
            height:200,
            width: 230,
            margin: const EdgeInsets.only(bottom: 16),
            child: Image.network('https://cdn.pixabay.com/photo/2012/03/01/00/55/flowers-19830_960_720.jpg',fit: BoxFit.cover)
        
      ),
       const Text('Indoor Plant', style: TextStyle(fontSize:13 ),),
       const Text('The Name of the plant', style: TextStyle(fontSize:16 ),)
        ],
    ),
    );
  }
}