import 'package:flutter/material.dart';

class Test extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
              backgroundColor: Colors.amber,
              title: const Text('Zingchong 2'),              
              ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        child:  Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 500,
              child: Image.network('https://cdn.pixabay.com/photo/2024/04/25/06/50/banana-8719086_1280.jpg',
              fit: BoxFit.cover,
              width: double.infinity,),
            ),

            Container(
              margin: const EdgeInsetsDirectional.only(top: 10),
              child: const Text(
                'The African Banana on Sale',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
            ),
            Row(

              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  margin: EdgeInsets.only(top:16),
                  child: Text('Price : Nu.230',style: TextStyle(fontSize: 13),
                  ),
                ),
                Icon(Icons.shopping_cart)
              ],
            ),
            Container(
              child: Text('The best banana from Africa is on sale for breif',
              style: TextStyle(fontSize: 15),),
            )

          ],

        ),

      ),
    );
  }
}