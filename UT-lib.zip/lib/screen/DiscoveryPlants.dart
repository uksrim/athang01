import 'package:athang_v01/widgets/PlantCart.dart';
import 'package:athang_v01/widgets/PlantLatest.dart';
import 'package:athang_v01/widgets/PlantRecommend.dart';
import 'package:athang_v01/widgets/PlantReviewed.dart';
import 'package:athang_v01/widgets/PlantSearchBar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class DiscoveryPlants extends StatelessWidget{
  const DiscoveryPlants({super.key});

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color.fromARGB(255, 255, 255, 255),title: const Text('Discovery of Plants')),
      body:  SingleChildScrollView(
        child: Column(
          children: [
            PlantSearchBar(),
            const PlantRecommend(),
            const PlantReviewed(),
            PlantLatest()
          ],
        )
      ),
    );
  }
}