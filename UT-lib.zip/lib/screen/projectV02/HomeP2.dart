import 'package:athang_v01/widgets/WidgetP2/AnimalSearch.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class HomeP2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          ClipOval(child: Image.network('https://cdn.pixabay.com/photo/2018/02/08/22/27/flower-3140492_1280.jpg',
          width: 50,height: 50, fit: BoxFit.cover,),)
        ],
        title: Container(
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('DISCOVERY', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
              Text('from Ugyen Tee', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),),
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            //link pages
            AnimalSearch(),
          ],
        ),
      ),
    );
  }
}
