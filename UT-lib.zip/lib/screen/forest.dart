import 'package:athang_v01/widgets/ProductCart.dart';
import 'package:athang_v01/widgets/ShortProduct.dart';
import 'package:athang_v01/widgets/SmallProductCart.dart';
import 'package:flutter/material.dart';
//import 'package:todo/widgets/SmallProductCard.dart';
class forest extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.amber, title: const Text('dZingchong')),
      body: SingleChildScrollView(
        child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ProductCard(),
                SmallProductCard(),
                SmallProductCard(),
                ShortProduct()
              ],
            )),
      ),
    );
  }
}